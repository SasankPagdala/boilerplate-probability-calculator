import copy
import random

class Hat:
  def __init__(self, **kwargs):
    self.contents = []  
    for k, v in kwargs.items():
      self.contents += v * [k]

  def draw(self, num):  
    try: 
      balls = random.sample(self.contents, num)
    except:
      balls = copy.deepcopy(self.contents)
    print("before", len(balls))
    
    for ball in balls:
      self.contents.remove(ball)
    print("after", balls)
    
    return balls

def experiment(hat, expected_balls, num_balls_drawn, num_experiments):
  M = 0
  for r in range(num_experiments):
    hat_copy = copy.deepcopy(hat)
    balls = hat_copy.draw(num_balls_drawn)
    
    # checking if num of balls match expectation
    eb_list = []
    for k, v in expected_balls.items():
      eb_list += v * [k]
      # ["blue", "blue", "green"]
        
    if contains_balls(eb_list, balls):
      M += 1

      
  probability = M / num_experiments
  return probability

def contains_balls(expected_balls, actual_balls):
    for k in expected_balls:
      if k in actual_balls:
        actual_balls.remove(k)
      else:
        return False 
    return True

# hat = Hat(blue=3, red=2, green=6)
# probability = experiment(hat=hat, expected_balls={"blue":2, "green":1}, 
# num_balls_drawn=4, num_experiments=1000)
# actual = probability
# expected = 0.272
# print("actual", actual)
# print("expected", expected)